/*
import 'package:flutter/material.dart';
import 'package:nawamin_hopital_web/MenuController.dart';
import 'package:nawamin_hopital_web/Responsive.dart';
import 'package:nawamin_hopital_web/Screen/DashboardScreen.dart';
import 'package:provider/provider.dart';
import 'Test/page/PatientList.dart';
import 'Wiget/SideMenu.dart';

class HomePage extends StatefulWidget {
  final String page;
*/
/*  final String extra;*//*


  const HomePage({
    Key? key,
    required this.page,
*/
/*    required this.extra,*//*

  }) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (context) => MenuController(),
          )
        ],
        child: Menu(

          page: widget.page,
        ),
      ),
    );
  }
}

List<String> testPages = [
  'test',
  'test2',
];

class Menu extends StatelessWidget {
  final String page;


  const Menu({
    Key? key,
    required this.page,

  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: context.read<MenuController>().scaffoldKey,
      drawer: Drawer(
        child: SingleChildScrollView(
          child: Column(
            children: testPages.map((e) {
              return SideMenu(
                selected: testPages.indexOf(e) == testPages.indexOf(page),
                title: e,
                onTap: () {
                  Navigator.pushNamed(
                      context, '/main/${testPages.indexOf(e)}');
                },
              );
            }).toList(),
          ),
        ),
      ),
      appBar: AppBar(
        leading: Responsive.isDesktop(context)
            ? null
            : IconButton(
                icon: Icon(Icons.menu),
                onPressed: context.read<MenuController>().controlMenu,
              ),
        title: Text("โรงพยาบาลค่ายนวมินืราชินี"),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFF38a687),
                const Color(0xFFe1faff),
              ],
              begin: FractionalOffset(
                0.0,
                0.0,
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (Responsive.isDesktop(context))
              Expanded(
                child: Drawer(
                  child: SingleChildScrollView(
                    child: Column(
                      children: testPages.map((e) {
                        return SideMenu(
                          selected: testPages.indexOf(e) == testPages.indexOf(page),
                          title: "test",
                          onTap: () {
                            Navigator.pushNamed(
                                context, '/main/${testPages.indexOf(e)}');
                          },
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),
            Expanded(
              flex: 4,
              child: Builder(
                builder: (context) {
                  return IndexedStack(
                    index: testPages.indexOf(page),
                    children: [
                      DashboardScreen(),
                      PatientList()

                    ],
                  );

             */
/*     if (_seleectedIndex == 0) {
                    return DashboardScreen();
                  } else if (_seleectedIndex == 1) {
                    return Text("test page 1");
                  } else {
                    return Text("test page 2");
                  }*//*

                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
*/
