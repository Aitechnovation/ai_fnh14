import 'package:flutter/material.dart';

class SwitchPage extends StatelessWidget {

  final Function page;

  const SwitchPage({Key? key, required this.page}) : super(key: key);




  @override
  Widget build(BuildContext context) {
    return page();
  }
}
