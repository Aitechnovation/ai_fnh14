import 'package:flutter/material.dart';

class DashboardCategory {
  final String id;
  final String title;
  final String numStr;

  const DashboardCategory(@required this.id,@required this.title,this.numStr);
}