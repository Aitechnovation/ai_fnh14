import 'package:flutter/material.dart';

class SideMenu extends StatefulWidget {
  final String title;
  final bool selected;
  final Function onTap;

  const SideMenu({
    Key? key,
    required this.title,
    required this.selected,
    required this.onTap,
  }) : super(key: key);

  @override
  _SideMenuState createState() => _SideMenuState();
}

class _SideMenuState extends State<SideMenu> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SingleChildScrollView(
        child: Column(
          children: [
            DrawerListTitle(
              title: "ภาพรวมระบบ",
              press: () {},
            ),
            DrawerListTitle(
              title: "รายชื่อผู้ป่วย",
              press: () {},
            ),
            DrawerListTitle(
              title: "ตั้งค่าระบบ",
              press: () {},
            ),
          ],
        ),
      ),
    );
  }
}

class DrawerListTitle extends StatelessWidget {
  const DrawerListTitle({
    Key? key,
    required this.title,
    required this.press,
  }) : super(key: key);

  final String title;
  final VoidCallback press;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: press,
      horizontalTitleGap: 0.0,
      title: Text("$title"),
    );
  }
}
