import 'package:flutter/material.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'โรงพยาบาลค่ายนวมินืราชินี',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: Scaffold(

      ),
    );
  }
}
