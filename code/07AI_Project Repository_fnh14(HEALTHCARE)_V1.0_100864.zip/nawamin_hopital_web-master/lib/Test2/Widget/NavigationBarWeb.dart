import 'package:flutter/material.dart';
import 'package:nawamin_hopital_web/Test2/Route/routes.dart';

import 'navigation_item.dart';

class NavigationBarWeb extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100.0,
      child: Container(
        height: 100.0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          mainAxisSize: MainAxisSize.max,
          children: [
            NavigationItem(title: 'Home',routeName: routeHome,),
            NavigationItem(title: 'About',routeName: routeAbout,),
          ],
        ),
      ),
    );
  }
}
