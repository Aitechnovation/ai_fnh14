import 'package:flutter/material.dart';

const String routeHome = '/home';
const String routeAbout = '/about';

final navKey = new GlobalKey<NavigatorState>();