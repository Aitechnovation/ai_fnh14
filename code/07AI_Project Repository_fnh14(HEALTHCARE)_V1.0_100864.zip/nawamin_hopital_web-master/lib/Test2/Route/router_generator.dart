
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:nawamin_hopital_web/Test2/Route/routes.dart';
import 'package:nawamin_hopital_web/Test2/TestScreen/about.dart';
import 'package:nawamin_hopital_web/Test2/TestScreen/home.dart';


class RouteGenerator{

  /*static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case routeHome:
        return MaterialPageRoute(builder:(context) => Home(),);
        break;
      case routeAbout:
        return MaterialPageRoute(builder: (context) =>  About());
        break;

    }
  }*/
}


