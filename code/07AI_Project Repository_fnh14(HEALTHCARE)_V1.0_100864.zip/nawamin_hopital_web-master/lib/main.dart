import 'package:flutter/material.dart';
import 'package:nawamin_hopital_web/LoginPage.dart';

/*import 'Test/SplashScreen.dart';*/
import 'package:nawamin_hopital_web/Test/Myapp.dart';
import 'package:nawamin_hopital_web/Test2/AppView.dart';

import 'Test2/Route/router_generator.dart';
import 'Test2/Route/routes.dart';
import 'Test2/TestScreen/about.dart';
import 'Test2/TestScreen/home.dart';

/*void main() {
  runApp(MyApp());
}*/

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Navigation Bar Web',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      builder: (context, child) => AppView(
        child: child,
      ) /* AppView(
        child: child,
      ),*/
      ,
      initialRoute: routeHome,
      navigatorKey: navKey,
      onGenerateRoute: (settings) {switch (settings.name) {
        case routeHome:
          return MaterialPageRoute(builder:(context) => Home(),);
          break;
        case routeAbout:
          return MaterialPageRoute(builder: (context) =>  About());
          break;

      }},
    );
  }
}

/*class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'โรงพยาบาลค่ายนวมินืราชินี',
      theme: ThemeData(
        primarySwatch: Colors.green,

      ),
      // home: MyHomePage(title: 'โรงพยาบาลค่ายนวมินืราชินี'),
      home:  MyApp(),
    );
  }
}*/

// class MyHomePage extends StatefulWidget {
//   MyHomePage({Key? key, required this.title}) : super(key: key);
//   final String title;
//
//   @override
//   _MyHomePageState createState() => _MyHomePageState();
// }
//
// class _MyHomePageState extends State<MyHomePage> {
//   int _counter = 0;
//
//   void _incrementCounter() {
//     setState(() {
//       _counter++;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(widget.title),
//         flexibleSpace: Container(
//           decoration: BoxDecoration(
//             gradient: ( LinearGradient(
//                 colors: [
//                   const Color(0xFF38a687),
//                   const Color(0xFFe1faff)],
//                 begin: const FractionalOffset(0.0, 0.0))),)
//           )
//       ),
//       body: Center(
//
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: <Widget>[
//             Text(
//               'You have pushed the button this many times:',
//             ),
//             Text(
//               '$_counter',
//               style: Theme.of(context).textTheme.headline4,
//             ),
//           ],
//         ),
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: _incrementCounter,
//         tooltip: 'Increment',
//         child: Icon(Icons.add),
//       ), // This trailing comma makes auto-formatting nicer for build methods.
//     );
//   }
// }
