import 'package:flutter/material.dart';
import 'package:nawamin_hopital_web/Responsive.dart';
import 'package:nawamin_hopital_web/Screen/AddPatientPage.dart';
import 'package:nawamin_hopital_web/Screen/DashboardScreen.dart';
import 'package:nawamin_hopital_web/Screen/PatientPage..dart';

class LandingPage extends StatefulWidget {
  final String page;

  const LandingPage({
    Key? key,
    required this.page,
  }) : super(key: key);

  @override
  _LandingPageState createState() => _LandingPageState();
}

List<String> pages = ['home', 'patient', 'addPatient','patientMenu'];

List<String> namePages = [
  'ภาพรวมระบบ',
  'รายชื่อผู้ป่วย',
  'เพิ่มผู้ป่วย',
];

class _LandingPageState extends State<LandingPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Responsive.isDesktop(context)
          ? null
          : Drawer(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    NavItem(
                      title: namePages[0],
                      selected: 'home' == widget.page,
                      onTap: () {
                        Navigator.pushNamed(
                            context, '/main/home');
                      },
                    ),
                    NavItem(
                      title: namePages[1],
                      selected: 'patient' == widget.page,
                      onTap: () {
                        Navigator.pushNamed(
                            context, '/main/patient');
                      },
                    )

                  ],
                ),
              ),
            ),
      appBar: AppBar(
        title: Text("โรงพยาบาลค่ายนวมินืราชินี"),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFF38a687),
                const Color(0xFFe1faff),
              ],
              begin: FractionalOffset(
                0.0,
                0.0,
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (Responsive.isDesktop(context))
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFF38a687),
                        const Color(0xFFe1faff),
                      ],
                      begin: FractionalOffset(
                        0.5,
                        0.0,
                      ),
                    ),
                  ),
                  child: Column(

                    children: [
                      NavItem(
                        title: namePages[0],
                        selected: 'home' == widget.page,
                        onTap: () {
                          Navigator.pushNamed(
                              context, '/main/home');
                        },
                      ),
                      NavItem(
                        title: namePages[1],
                        selected: 'patient' == widget.page,
                        onTap: () {
                          Navigator.pushNamed(
                              context, '/main/patient');
                        },
                      )

                    ], /*pages.map((e) {
                      return NavItem(
                        selected: pages.indexOf(e) == pages.indexOf(widget.page),
                        title: namePages[pages.indexOf(e)],
                        onTap: () {
                          Navigator.pushNamed(
                              context, '/main/${pages[pages.indexOf(e)]}');
                        },
                      );
                    }).toList(),*/
                  ),
                ),
              ),
            Expanded(

              flex: 4,
              child: IndexedStack(
                index: pages.indexOf(widget.page),
                children: [
                  DashboardScreen(),
                  PatientPage(),
                  AddPatient(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class NavItem extends StatefulWidget {
  final String title;
  final bool selected;
  final Function onTap;

  const NavItem(
      {Key? key,
      required this.title,
      required this.selected,
      required this.onTap})
      : super(key: key);
  @override
  _NavItemState createState() => _NavItemState();
}

class _NavItemState extends State<NavItem> {
  @override
  Widget build(BuildContext context) {
    return Material(
/*        color: Colors.transparent,*/
      child: InkWell(
        onTap: () {
          widget.onTap();
        },
        child: AnimatedContainer(

          duration: Duration(milliseconds: 900),
          width: double.infinity,
          height: 60.0,
          color: widget.selected ? Colors.white : Color(0xFF38a687),
          child: Center(
            child: Container(
              child: Text(
                widget.title,
                style: TextStyle(
                  color:  Colors.black87,
                  fontSize: 20,
                ),
                /*color: widget.selected ? Colors.white : Colors.black87,*/
              ),
            ),
          ),
        ),
      ),
    );
  }
}
