
import 'package:fluro/fluro.dart';

import 'package:nawamin_hopital_web/LoginPage.dart';
import 'package:nawamin_hopital_web/Test/LandingPage.dart';

class Flurorouter {
  static final FluroRouter router = FluroRouter();

  static Handler _LoginHandler = Handler(
    handlerFunc: (context, params) => LoginPage(),
  );

  static Handler _mainHandler = Handler(
    handlerFunc: (context, Map<String, dynamic> params) => LandingPage(
      page: params['name'][0]/*,extra: params['extra'][0]*/
    ),
  );



 /* static Handler _mainHandler2 = Handler(
    handlerFunc: (context, Map<String, dynamic> params) => LandingPage(
      page: params['name'][0],
      extra: params['extra'][0],
    ),
  );*/

  static void setupRouter() {
    router.define(
      '/',
      handler: _LoginHandler,
    );
    router.define(
      '/main/:name',
      handler: _mainHandler,
      transitionType: TransitionType.fadeIn,
    );
    /*router.define(
      '/main/:name/:extra',
      handler: _mainHandler2,
      transitionType: TransitionType.fadeIn,
    );*/
  }
}
