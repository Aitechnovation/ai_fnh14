import 'package:flutter/material.dart';
import 'package:nawamin_hopital_web/LoginPage.dart';
import 'package:nawamin_hopital_web/Test/Routes.dart';

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  void initState() {
    // TODO: implement initState
    Flurorouter.setupRouter();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      initialRoute: '/',
      onGenerateRoute: Flurorouter.router.generator,
    );
  }
}
