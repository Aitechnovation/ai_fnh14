import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:nawamin_hopital_web/Responsive.dart';
import 'package:nawamin_hopital_web/Wiget/Header.dart';
import 'package:nawamin_hopital_web/Model/DashboardCategory.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  Widget build(BuildContext context) {
    /*   var size = MediaQuery.of(context).size;
    final double itemHeight = (size.height - kToolbarHeight) / 1.5;
    final double itemWidth = size.width / 2;*/

    final Size _size = MediaQuery.of(context).size;

    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Header(
              title: "ภาพรวมระบบ",
            ),
            SizedBox(
              height: 20,
            ),
            Responsive(
              mobile: CardGridView(
                crossAxiscount: 2,
              ),
              tablet: CardGridView(crossAxiscount: 3),
              desktop: CardGridView(
                childAspectRatio: _size.width < 1400 ? 1.1 : 1.4,
              ),
            )
          ],
        ),
      ),
    );
  }
}

const CATEGORIES = const [
  DashboardCategory("1", "ผู้ป่วย", "10,000,000"),
  DashboardCategory("2", "จำนวนแพทย์", "200"),
  DashboardCategory("3", "จำนวนส่งต่อ", "50"),
];

class CardGridView extends StatelessWidget {
  const CardGridView({
    Key? key,
/*    required this.itemWidth,
    required this.itemHeight,*/
    this.crossAxiscount = 3,
    this.childAspectRatio = 1,
  }) : super(key: key);

/*  final double itemWidth;
  final double itemHeight;*/

  final int crossAxiscount;
  final double childAspectRatio;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: CATEGORIES.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxiscount,
        childAspectRatio: childAspectRatio,
        crossAxisSpacing: 20,
        mainAxisSpacing: 20,
      ),
      itemBuilder: (context, index) => ItemDashboard(
        title: CATEGORIES[index].title,
        numStr: CATEGORIES[index].numStr,
      ),
    );
  }
}

class ItemDashboard extends StatelessWidget {
  const ItemDashboard({
    Key? key,
    required this.title,
    required this.numStr,
  }) : super(key: key);

  final String title;
  final String numStr;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Center(
        child: Padding(
          padding: Responsive.isMobile(context)
              ? const EdgeInsets.all(5.0)
              : const EdgeInsets.fromLTRB(10, 15, 10, 15),
          child: Column(
            children: [
              Text(
                "$title",
                style: TextStyle(
                  fontSize: Responsive.isMobile(context)
                      ? 10
                      : Responsive.isTablet(context)
                          ? 25
                          : 30,
                ),
              ),
              Divider(color: Colors.black),
              Container(
                width: Responsive.isMobile(context)
                    ? 100
                    : Responsive.isTablet(context)
                        ? 250
                        : 350,
                height: Responsive.isMobile(context)
                    ? 70
                    : Responsive.isTablet(context)
                        ? 150
                        : 180,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Center(
                  child: Text(
                    "$numStr " + "คน",
                    style: TextStyle(
                      fontSize: Responsive.isMobile(context)
                          ? 10
                          : Responsive.isTablet(context)
                              ? 25
                              : 30,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
