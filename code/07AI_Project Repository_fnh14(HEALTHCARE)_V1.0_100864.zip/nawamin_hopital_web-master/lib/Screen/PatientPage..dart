import 'package:flutter/material.dart';
import 'package:nawamin_hopital_web/Screen/PatientMenu.dart';
import 'package:nawamin_hopital_web/Wiget/Header.dart';
import 'package:data_table_2/data_table_2.dart';

class PatientPage extends StatefulWidget {
  const PatientPage({Key? key}) : super(key: key);

  @override
  _PatientPageState createState() => _PatientPageState();
}

var tests = [
  Test(
      num: 1,
      name: "เอกพจน์" + " " + "เพชรแก้ว",
      dayReceive: "12-05-2556",
      daySend: " - ",
      status: "ส่งตัวแล้ว"),
  Test(
    num: 2,
    name: "Test",
    dayReceive: "02-05-2556",
    daySend: " - ",
    status: "ยังไม่ส่งตัว",
  ),
];

class _PatientPageState extends State<PatientPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Header(
              title: "รายชื่อผู้ป่วย",
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              children: [
                Flexible(
                  child: TextField(
                    decoration: InputDecoration(
                      labelText: "ชื่อ - นามสกุล",
                      border: OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(10.0),
                        borderSide: new BorderSide(),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                Flexible(
                  child: TextField(
                    decoration: InputDecoration(
                      labelText: "วันที่",
                      border: OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(10.0),
                        borderSide: new BorderSide(),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                Flexible(
                  child: TextField(
                    decoration: InputDecoration(
                      labelText: "ถึงวันที่",
                      border: OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(10.0),
                        borderSide: new BorderSide(),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, 'main/addPatient');
                  },
                  child: Text("เพิ่มผู้ป่วย"),
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(
                      100,
                      MediaQuery.of(context).size.height * 0.07,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                ElevatedButton(
                  onPressed: () {},
                  child: Text("ค้นหา"),
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(
                      100,
                      MediaQuery.of(context).size.height * 0.07,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            DataTable2(
              columns: [
                DataColumn2(label: Text("ลำดับ")),
                DataColumn2(label: Text("ชื่อ - นามสกุล")),
                DataColumn2(label: Text("วันที่รับตัว")),
                DataColumn2(label: Text("วันที่ส่งต่อ")),
                DataColumn2(label: Text("สถานะ")),
                DataColumn2(label: Text("")),
              ],
              rows: tests
                  .map(
                    (e) => DataRow2(
                      cells: [
                        DataCell(
                          Text("${e.num}"),
                        ),
                        DataCell(
                          Text(e.name),
                        ),
                        DataCell(
                          Text(e.dayReceive),
                        ),
                        DataCell(
                          Text(e.daySend),
                        ),
                        DataCell(
                          Text(e.status),
                        ),
                        DataCell(
                          ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => PatientMenu()),
                              );
                            },
                            child: Text("รายละเอียด"),
                            style: ElevatedButton.styleFrom(
                              primary: Colors.green,
                              minimumSize: Size(
                                100,
                                50,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(50),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}

class Test {
  int num;
  String name;
  String dayReceive;
  String daySend;
  String status;

  Test(
      {required this.num,
      required this.name,
      required this.dayReceive,
      required this.daySend,
      required this.status});
}
