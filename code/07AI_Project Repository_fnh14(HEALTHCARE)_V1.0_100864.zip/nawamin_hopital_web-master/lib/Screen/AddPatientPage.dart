import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:nawamin_hopital_web/Wiget/Header.dart';

class AddPatient extends StatefulWidget {
  const AddPatient({Key? key}) : super(key: key);

  @override
  _AddPatientState createState() => _AddPatientState();
}

class _AddPatientState extends State<AddPatient> {
  @override
  Widget build(BuildContext context) {

    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Header(
              title: "รายชื่อผู้ป่วย",
            ),
            SizedBox(
              height: 50,
            ),
            Row(
              children: [
                Flexible(
                  child: DropdownSearch<String>(
                    showSearchBox: true,
                    mode: Mode.MENU,
                    showSelectedItem: true,
                    items: [
                      "โรงพยาบาลบำราษ",
                      "โรงพยาบาลxxx",
                      "โรงพยาบาลsss",
                      'โรงพยาบาลaaa'
                    ],
                    label: "โรงพยาบาล",
                    // hint: "country in menu mode",
                    /*popupItemDisabled: (String s) => s.startsWith('I'),*/
                    onChanged: print,
                    /*selectedItem: "Brazil"*/
                  ),
                ),
                SizedBox(
                  width: 50,
                ),
                Flexible(
                  child: DropdownSearch<String>(
                    showSearchBox: true,
                    mode: Mode.MENU,
                    showSelectedItem: true,
                    items: [
                      "test test",
                      "xxx yyy",
                      "yyy zzz",
                      "zzz 111"
                    ],
                    label: "ชื่อ - นามสกุลผู้ป่วย",
                    // hint: "country in menu mode",
                    /*popupItemDisabled: (String s) => s.startsWith('I'),*/
                    onChanged: print,
                    /*selectedItem: "Brazil"*/
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text("ย้อนกลับ"),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.yellow,
                    minimumSize: Size(
                      100,
                      50,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {},
                  child: Text("บันทึก"),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.green,
                    minimumSize: Size(
                      100,
                      50,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
