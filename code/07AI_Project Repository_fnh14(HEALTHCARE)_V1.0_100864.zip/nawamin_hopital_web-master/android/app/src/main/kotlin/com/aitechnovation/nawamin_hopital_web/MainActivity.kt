package com.aitechnovation.nawamin_hopital_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
